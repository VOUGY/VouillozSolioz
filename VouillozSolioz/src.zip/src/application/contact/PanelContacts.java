package application.contact;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneLayout;

public class PanelContacts extends JPanel {
	Contacts myContacts = new Contacts();
	
	JPanel myPanel = new JPanel();
	public PanelContacts()
	{
		
		
		
	}
}
